//Q1: Write program for OutofMemory Exception and its prevention (Its design issue 
//or memory leak differentiate it.)

package io.exceptionHandling;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Q1 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter no. of Objects you to store : ");
		int size = scan.nextInt();
		List<Object> list = new ArrayList<>();

		try {
			while (true) {
                // Allocate memory for each object
                for (int i = 0; i < size; i++) {
                    list.add(new Byte[1024 * 1024]); // Adding 1 MB objects
                }
                size += size;
                System.out.println("Allocated " + size + " MB");
            }
			
		} catch (OutOfMemoryError e) {
			System.out.println("Error allocating "+size+" MB");
		}
	}

}
